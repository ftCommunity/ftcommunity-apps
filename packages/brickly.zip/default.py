# highlightBlock('KD8.vwB-H@^)YNa0$*xC');
print('Hallo TXT!')
# highlightBlock('NtPjn#U9nUK4xc,WRVag');
setOutput(0, (True))
# highlightBlock('X{d7^ZM~^-(:FV;PGB*5');
time.sleep(1)
# highlightBlock('Ph`X:459g*:B3tf~hH}J');
setOutput(0, (False))
