# Brickly

Brickly is a port of [Blockly](https://developers.google.com/blockly/)
to the [Fischertechnik TXT](http://www.fischertechnik.de/en/desktopdefault.aspx/tabid-21/39_read-309/usetemplate-2_column_pano/). Brickly allows to program the TXT from any web browser
using a simple graphical user interface. If you don't have a TXT then
the [Blocly Games](https://blockly-games.appspot.com/) can give you 
a first impression how Blockly looks and works.

