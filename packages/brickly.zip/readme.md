# Brickly

Brickly is a port of [Blockly](https://developers.google.com/blockly/)
to the [fischertechnik TXT Controller](https://www.fischertechnik.de/en/products/playing/robotics/522429-txt-controller). Brickly allows to program the TXT from any web browser
using a simple graphical user interface. If you don't have a TXT then
the [Blockly Games](https://blockly.games/) can give you 
a first impression how Blockly looks and works.

