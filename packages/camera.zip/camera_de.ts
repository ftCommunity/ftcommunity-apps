<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE" sourcelanguage="en">
<context>
    <name>Main</name>
    <message>
        <location filename="camera.py" line="63"/>
        <source>No camera</source>
        <translation>Keine Kamera</translation>
    </message>
    <message>
        <location filename="camera.py" line="83"/>
        <source>Camera</source>
        <translation>Kamera</translation>
    </message>
</context>
</TS>
