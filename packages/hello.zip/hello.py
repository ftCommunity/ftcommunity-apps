#! /usr/bin/env python3
import time

print("Hello world!")

for i in range(5):
    print("Counter:", i)
    time.sleep(1)

print("Done")

exit(42)
