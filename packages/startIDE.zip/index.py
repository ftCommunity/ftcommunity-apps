#!/usr/bin/python3

from translator import *

print(translate("This is a test","fr"));
