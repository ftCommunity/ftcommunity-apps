<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>addcodeline</name>
    <message>
        <location filename="startide.py" line="5743"/>
        <source>New cmd:</source>
        <translation>Neuer Befehl:</translation>
    </message>
    <message>
        <location filename="startide.py" line="5760"/>
        <source>Inputs</source>
        <translation>Eingänge</translation>
    </message>
    <message>
        <location filename="startide.py" line="5786"/>
        <source>Outputs</source>
        <translation>Ausgänge</translation>
    </message>
    <message>
        <location filename="startide.py" line="5855"/>
        <source>Controls</source>
        <translation>Steuerung</translation>
    </message>
    <message>
        <location filename="startide.py" line="5900"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="5918"/>
        <source>Interaction</source>
        <translation>Interaktion</translation>
    </message>
    <message>
        <location filename="startide.py" line="5773"/>
        <source>WaitForInputDig</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5775"/>
        <source>IfInputDig</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5802"/>
        <source>Output</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5803"/>
        <source>Motor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5804"/>
        <source>MotorPulsew.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5805"/>
        <source>MotorEnc</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5806"/>
        <source>MotorEncSync</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5868"/>
        <source># comment</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5869"/>
        <source>Tag</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5870"/>
        <source>Jump</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5871"/>
        <source>LoopTo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5886"/>
        <source>Delay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5897"/>
        <source>Stop</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5912"/>
        <source>Call</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5914"/>
        <source>Return</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5915"/>
        <source>Module</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5916"/>
        <source>MEnd</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5919"/>
        <source>Interact</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5930"/>
        <source>Print</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5931"/>
        <source>Clear</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5932"/>
        <source>Message</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5829"/>
        <source>Variables</source>
        <translation>Variable</translation>
    </message>
    <message>
        <location filename="startide.py" line="5777"/>
        <source>WaitForInput</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5779"/>
        <source>IfInput</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5781"/>
        <source>QueryInput</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5827"/>
        <source>Init</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5828"/>
        <source>From...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5850"/>
        <source>QueryVar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5851"/>
        <source>IfVar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5852"/>
        <source>Calc</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5844"/>
        <source>FromIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5845"/>
        <source>FromKeypad</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5846"/>
        <source>FromDial</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5847"/>
        <source>FromButtons</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5849"/>
        <source>Shelf</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5873"/>
        <source>Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5887"/>
        <source>TimerQuery</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5889"/>
        <source>TimerClear</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5891"/>
        <source>IfTimer</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5893"/>
        <source>Interrupt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5895"/>
        <source>QueryNow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5913"/>
        <source>CallExt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6057"/>
        <source>Logfile</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6067"/>
        <source>Log On</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6068"/>
        <source>Log Off</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6069"/>
        <source>Log Clear</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5783"/>
        <source>CounterClear</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ecl</name>
    <message>
        <location filename="startide.py" line="1837"/>
        <source>Condition</source>
        <translation>Bedingung</translation>
    </message>
    <message>
        <location filename="startide.py" line="4348"/>
        <source>Value</source>
        <translation>Wert</translation>
    </message>
    <message>
        <location filename="startide.py" line="2714"/>
        <source>Direction</source>
        <translation>Drehrichtung</translation>
    </message>
    <message>
        <location filename="startide.py" line="2720"/>
        <source>right</source>
        <translation>rechts</translation>
    </message>
    <message>
        <location filename="startide.py" line="2720"/>
        <source>left</source>
        <translation>links</translation>
    </message>
    <message>
        <location filename="startide.py" line="2720"/>
        <source>stop</source>
        <translation>stop</translation>
    </message>
    <message>
        <location filename="startide.py" line="2526"/>
        <source>End Sw.</source>
        <translation>Endschalter</translation>
    </message>
    <message>
        <location filename="startide.py" line="2314"/>
        <source>Pulse Inp.</source>
        <translation>Impulseingang</translation>
    </message>
    <message>
        <location filename="startide.py" line="2848"/>
        <source>Pulses</source>
        <translation>Impulse</translation>
    </message>
    <message>
        <location filename="startide.py" line="2736"/>
        <source>Sync to</source>
        <translation>Sync mit</translation>
    </message>
    <message>
        <location filename="startide.py" line="2879"/>
        <source>Loop target</source>
        <translation>Sprungziel</translation>
    </message>
    <message>
        <location filename="startide.py" line="2992"/>
        <source>Count</source>
        <translation>Anzahl</translation>
    </message>
    <message>
        <location filename="startide.py" line="5294"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="startide.py" line="6432"/>
        <source>Module</source>
        <translation>Modul</translation>
    </message>
    <message>
        <location filename="startide.py" line="6401"/>
        <source>No Tags defined!</source>
        <translation>Keine Tags definiert!</translation>
    </message>
    <message>
        <location filename="startide.py" line="6446"/>
        <source>No Modules defined!</source>
        <translation>Keine Module definiert!</translation>
    </message>
    <message>
        <location filename="startide.py" line="6468"/>
        <source>Message</source>
        <translation>Nachricht</translation>
    </message>
    <message>
        <location filename="startide.py" line="4105"/>
        <source>Inp. type</source>
        <translation>Eing.-Art</translation>
    </message>
    <message>
        <location filename="startide.py" line="3110"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="startide.py" line="1668"/>
        <source>WaitInDig</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4068"/>
        <source>Device</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4086"/>
        <source>Port</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3826"/>
        <source>Timeout</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="1777"/>
        <source>TOut</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6185"/>
        <source>IfInDig</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="1940"/>
        <source>Output</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2059"/>
        <source>Motor</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2208"/>
        <source>MotorP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2438"/>
        <source>MotorE</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="2648"/>
        <source>MotorES</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6360"/>
        <source>LoopTo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4179"/>
        <source>switch</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4179"/>
        <source>voltage</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4179"/>
        <source>resistance</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4179"/>
        <source>distance</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6449"/>
        <source>Okay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6327"/>
        <source>Comment</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6330"/>
        <source>Tag</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6349"/>
        <source>Jump</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6349"/>
        <source>Target</source>
        <translation>Sprungziel</translation>
    </message>
    <message>
        <location filename="startide.py" line="6381"/>
        <source>Delay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6444"/>
        <source>Call</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6461"/>
        <source>Print</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6468"/>
        <source>BtnTxt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="106"/>
        <source>Variables</source>
        <translation>Variable</translation>
    </message>
    <message>
        <location filename="startide.py" line="93"/>
        <source>No Variables defined!</source>
        <translation>Keine Variablen definiert!</translation>
    </message>
    <message>
        <location filename="startide.py" line="106"/>
        <source>Select variable</source>
        <translation>Variable wählen</translation>
    </message>
    <message>
        <location filename="startide.py" line="3697"/>
        <source>Number</source>
        <translation>Zahl</translation>
    </message>
    <message>
        <location filename="startide.py" line="3047"/>
        <source>QueryIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3217"/>
        <source>IfInput</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4392"/>
        <source>Operator</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3463"/>
        <source>WaitIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6399"/>
        <source>IfTimer</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6315"/>
        <source>Calc</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6417"/>
        <source>Interrupt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3921"/>
        <source>Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3889"/>
        <source>Target module</source>
        <translation>Zielmodul</translation>
    </message>
    <message>
        <location filename="startide.py" line="6281"/>
        <source>Variable</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="3950"/>
        <source>Variable name</source>
        <translation>Variablenname</translation>
    </message>
    <message>
        <location filename="startide.py" line="4020"/>
        <source>Name</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4052"/>
        <source>FromIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6302"/>
        <source>IfVar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4375"/>
        <source>First Operand</source>
        <translation>Erster Operand</translation>
    </message>
    <message>
        <location filename="startide.py" line="4409"/>
        <source>Second Operand</source>
        <translation>Zweiter Operand</translation>
    </message>
    <message>
        <location filename="startide.py" line="4425"/>
        <source>Target variable</source>
        <translation>Zielvariable</translation>
    </message>
    <message>
        <location filename="startide.py" line="4478"/>
        <source>1st Op.</source>
        <translation>1. Operand</translation>
    </message>
    <message>
        <location filename="startide.py" line="4501"/>
        <source>2nd Op.</source>
        <translation>2. Operand</translation>
    </message>
    <message>
        <location filename="startide.py" line="6244"/>
        <source>FromKeypad</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4685"/>
        <source>Min value</source>
        <translation>Minimum</translation>
    </message>
    <message>
        <location filename="startide.py" line="4702"/>
        <source>Max value</source>
        <translation>Maximum</translation>
    </message>
    <message>
        <location filename="startide.py" line="4773"/>
        <source>Min</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4805"/>
        <source>Max</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4648"/>
        <source>FromDial</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6257"/>
        <source>FromButtons</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4824"/>
        <source>Buttons</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4854"/>
        <source>Up</source>
        <translation>Auf</translation>
    </message>
    <message>
        <location filename="startide.py" line="4861"/>
        <source>Dn</source>
        <translation>Ab</translation>
    </message>
    <message>
        <location filename="startide.py" line="4920"/>
        <source>Btn. Text</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6202"/>
        <source>IfIn</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6281"/>
        <source>QueryVar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="6317"/>
        <source>No variables defined!</source>
        <translation>Keine Variablen definiert!</translation>
    </message>
    <message>
        <location filename="startide.py" line="1880"/>
        <source>CounterClear</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="4179"/>
        <source>counter</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>exec</name>
    <message>
        <location filename="startide.py" line="351"/>
        <source>TXT not found!
Program terminated
</source>
        <translation>TXT nicht gefunden!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="354"/>
        <source>RoboIF not found!
Program terminated
</source>
        <translation>RoboInterface nicht gefunden!
Programm abgebochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="372"/>
        <source>MEnd found with-
out Module!
Program terminated
</source>
        <translation>MEnd ohne Modul!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="375"/>
        <source>MEnd missing!
Program terminated
</source>
        <translation>MEnd fehlt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="378"/>
        <source>TXT M1 and O1/O2
used in parallel!
Program terminated
</source>
        <translation>TXT M1 und O1/O2
gleichtzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="381"/>
        <source>TXT M2 and O3/O4
used in parallel!
Program terminated
</source>
        <translation>TXT M2 und O3/O4
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="384"/>
        <source>TXT M3 and O5/O6
used in parallel!
Program terminated
</source>
        <translation>TXT M3 und O5/O6
gleichzeitig belegt.
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="229"/>
        <source>TXT M1 and O7/O8
used in parallel!
Program terminated
</source>
        <translation type="obsolete">TXT M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="390"/>
        <source>RIF M1 and O1/O2
used in parallel!
Program terminated
</source>
        <translation>RIF M1 und O1/O2
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="393"/>
        <source>RIF M2 and O3/O4
used in parallel!
Program terminated
</source>
        <translation>RIF M2 und O3/O4
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="396"/>
        <source>RIF M3 and O5/O6
used in parallel!
Program terminated
</source>
        <translation>RIF M3 und O5/O6
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="241"/>
        <source>RIF M1 and O7/O8
used in parallel!
Program terminated
</source>
        <translation type="obsolete">RIF M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="418"/>
        <source>M3 and M4 not available
on Robo LT!
Program terminated
</source>
        <translation>M3 und M4 nicht vor-
handen am Robo LT!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="421"/>
        <source>O5 to O8 not available
on Robo LT!
Program terminated
</source>
        <translation>O5 bis O8 nicht vor-
handen am Robo LT!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="424"/>
        <source>I4 to I8 not available
on Robo LT!
Program terminated
</source>
        <translation>I4 bis I8 nicht vor-
handen am Robo LT!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="5678"/>
        <source>Message</source>
        <translation>Nachricht</translation>
    </message>
    <message>
        <location filename="startide.py" line="357"/>
        <source>ftduino not found!
Program terminated
</source>
        <translation>ftduino nicht gefunden!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="402"/>
        <source>FTD M1 and O1/O2
used in parallel!
Program terminated
</source>
        <translation>FTD M1 und O1/O2
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="405"/>
        <source>FTD M2 and O3/O4
used in parallel!
Program terminated
</source>
        <translation>FTD M2 und O3/O4
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="408"/>
        <source>FTD M3 and O5/O6
used in parallel!
Program terminated
</source>
        <translation>FTD M3 und O5/O6
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="253"/>
        <source>FTD M1 and O7/O8
used in parallel!
Program terminated
</source>
        <translation type="obsolete">FTD M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="387"/>
        <source>TXT M4 and O7/O8
used in parallel!
Program terminated
</source>
        <translation>TXT M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="399"/>
        <source>RIF M4 and O7/O8
used in parallel!
Program terminated
</source>
        <translation>RIF M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="411"/>
        <source>FTD M4 and O7/O8
used in parallel!
Program terminated
</source>
        <translation>FTD M4 und O7/O8
gleichzeitig belegt!
Programm abgebrochen</translation>
    </message>
    <message>
        <location filename="startide.py" line="363"/>
        <source>TXT analog I</source>
        <translation>TXT Eingang I</translation>
    </message>
    <message>
        <location filename="startide.py" line="366"/>
        <source>
types inconsistent!
Program terminated
</source>
        <translation>Typen inkonsistent!
Programm abgebrochen
</translation>
    </message>
    <message>
        <location filename="startide.py" line="360"/>
        <source>External Module</source>
        <translation>Externes Modul</translation>
    </message>
    <message>
        <location filename="startide.py" line="360"/>
        <source>not found.
Program terminated
</source>
        <translation>nicht gefunden.
Programm abgebrochen
</translation>
    </message>
    <message>
        <location filename="startide.py" line="366"/>
        <source>FTD analog I</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="369"/>
        <source>FTD counter C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="369"/>
        <source>
counter/distance mismatch!
Program terminated
</source>
        <translation>
counter/distance Unstimmigkeit!
Programm abgebrochen
</translation>
    </message>
</context>
<context>
    <name>m_about</name>
    <message>
        <location filename="startide.py" line="5160"/>
        <source>About</source>
        <translation>Über</translation>
    </message>
    <message>
        <location filename="startide.py" line="5162"/>
        <source>A tiny IDE to control Robo Family Interfaces and TXT Hardware.</source>
        <translation>Eine Mini-IDE zum Steuern von Robo Interfaces und TXT Hardware.</translation>
    </message>
    <message>
        <location filename="startide.py" line="1754"/>
        <source>The manual is available in the webinterface under &apos;Get more app info&apos;.</source>
        <translation type="obsolete">Das Handbuch liegt im Webinterface unter &apos;Get more app info&apos;. </translation>
    </message>
    <message>
        <location filename="startide.py" line="5162"/>
        <source>The manual is available in the TXT startIDE webinterface under &apos;Get more app info&apos;.</source>
        <translation>Das Handbuch ist im TXT startIDE webinterface unter &apos;Get more app info&apos; verfügbar.</translation>
    </message>
    <message>
        <location filename="startide.py" line="5171"/>
        <source>News</source>
        <translation>News</translation>
    </message>
    <message>
        <location filename="startide.py" line="5167"/>
        <source>Okay</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>m_interfaces</name>
    <message>
        <location filename="startide.py" line="5484"/>
        <source>No Robo device</source>
        <translation>Kein Robo Gerät</translation>
    </message>
    <message>
        <location filename="startide.py" line="5487"/>
        <source>No TXT device</source>
        <translation>Kein TXT Gerät</translation>
    </message>
    <message>
        <location filename="startide.py" line="5488"/>
        <source>TXT found</source>
        <translation>TXT gefunden</translation>
    </message>
    <message>
        <location filename="startide.py" line="5493"/>
        <source>Hardware found:</source>
        <translation>Gefundene Hardware:</translation>
    </message>
    <message>
        <location filename="startide.py" line="5495"/>
        <source>Interfaces</source>
        <translation>Interfaces</translation>
    </message>
    <message>
        <location filename="startide.py" line="5490"/>
        <source>No ftduino device</source>
        <translation>Kein ftduino</translation>
    </message>
    <message>
        <location filename="startide.py" line="5491"/>
        <source>found</source>
        <translation>gefunden</translation>
    </message>
    <message>
        <location filename="startide.py" line="5500"/>
        <source>Okay</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5516"/>
        <source>Enable IIF</source>
        <translation>IIf aktivieren</translation>
    </message>
    <message>
        <location filename="startide.py" line="5507"/>
        <source>Enabling IIF with any device other than an Intelligent Interface connected to &apos;/dev/ttyUSB0&apos; will crash startIDE.</source>
        <translation>Aktivieren des IIf ohne angeschlossenes Interface an /dev/ttyUSB0 führt zum Programmabsturz.</translation>
    </message>
    <message>
        <location filename="startide.py" line="5513"/>
        <source>Cancel</source>
        <translation>Abbrechen
</translation>
    </message>
</context>
<context>
    <name>m_modules</name>
    <message>
        <location filename="startide.py" line="5343"/>
        <source>Import</source>
        <translation>Importieren</translation>
    </message>
    <message>
        <location filename="startide.py" line="5408"/>
        <source>Module</source>
        <translation>Modul</translation>
    </message>
    <message>
        <location filename="startide.py" line="5458"/>
        <source>No saved modules found.</source>
        <translation>Keine gespeicherten Module gefunden.</translation>
    </message>
    <message>
        <location filename="startide.py" line="5398"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="5391"/>
        <source>MEnd found with-
out Module!
Please fix before export!
</source>
        <translation>MEnd ohne Modul gefunden.
Bitte vor Export reparieren!</translation>
    </message>
    <message>
        <location filename="startide.py" line="5400"/>
        <source>MEnd missing!
Please fix before export!
</source>
        <translation>MEnd fehlt!
Bitte vor Export reparieren!</translation>
    </message>
    <message>
        <location filename="startide.py" line="5427"/>
        <source>Export</source>
        <translation>Exportieren</translation>
    </message>
    <message>
        <location filename="startide.py" line="5412"/>
        <source>No modules found.</source>
        <translation>Keine Module gefunden.</translation>
    </message>
    <message>
        <location filename="startide.py" line="5429"/>
        <source>A module file with this name already exists. Do you want to overwrite it?</source>
        <translation>Ein Modul mit diesem Namen existiert schon. Überschreiben?</translation>
    </message>
    <message>
        <location filename="startide.py" line="5474"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="startide.py" line="5471"/>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <location filename="startide.py" line="5466"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="startide.py" line="5468"/>
        <source>Do you really want to permanently delete this module?</source>
        <translation>Soll das Modul wirklich für immer gelöscht werden?</translation>
    </message>
    <message>
        <location filename="startide.py" line="5460"/>
        <source>Okay</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>m_project</name>
    <message>
        <location filename="startide.py" line="5183"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="startide.py" line="5203"/>
        <source>New</source>
        <translation>Neu</translation>
    </message>
    <message>
        <location filename="startide.py" line="5239"/>
        <source>Load</source>
        <translation>Laden</translation>
    </message>
    <message>
        <location filename="startide.py" line="5269"/>
        <source>Save</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <location filename="startide.py" line="5334"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="startide.py" line="5225"/>
        <source>Current project was not saved. Do you want to discard it?</source>
        <translation>Projekt ist nicht gespeichert. Soll es gelöscht werden?</translation>
    </message>
    <message>
        <location filename="startide.py" line="5314"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="startide.py" line="5311"/>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <location filename="startide.py" line="5298"/>
        <source>No saved projects found.</source>
        <translation>Keine gespeicherten Projekte.</translation>
    </message>
    <message>
        <location filename="startide.py" line="5260"/>
        <source>Enter project file name:</source>
        <translation>Projektnamen eingeben:</translation>
    </message>
    <message>
        <location filename="startide.py" line="5271"/>
        <source>A file with this name already exists. Do you want to overwrite it?</source>
        <translation>Ein Projekt mit diesem Namen existiert schon. Überschreiben?</translation>
    </message>
    <message>
        <location filename="startide.py" line="5308"/>
        <source>Do you really want to permanently delete this project?</source>
        <translation>Soll das Projekt wirklich für immer gelöscht werden?</translation>
    </message>
    <message>
        <location filename="startide.py" line="5321"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="5332"/>
        <source>Import</source>
        <translation>Import</translation>
    </message>
    <message>
        <location filename="startide.py" line="5333"/>
        <source>Export</source>
        <translation>Export</translation>
    </message>
    <message>
        <location filename="startide.py" line="5300"/>
        <source>Okay</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="startide.py" line="5610"/>
        <source>Close log</source>
        <translation>Schließe Log</translation>
    </message>
    <message>
        <location filename="startide.py" line="5074"/>
        <source>Up</source>
        <translation>Auf</translation>
    </message>
    <message>
        <location filename="startide.py" line="5078"/>
        <source>Dn</source>
        <translation>Ab</translation>
    </message>
    <message>
        <location filename="startide.py" line="5730"/>
        <source>Start</source>
        <translation></translation>
    </message>
    <message>
        <location filename="startide.py" line="5732"/>
        <source>Stop</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>mmain</name>
    <message>
        <location filename="startide.py" line="4993"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="startide.py" line="4998"/>
        <source>Modules</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="startide.py" line="5008"/>
        <source>About</source>
        <translation>Über</translation>
    </message>
    <message>
        <location filename="startide.py" line="5003"/>
        <source>Interfaces</source>
        <translation></translation>
    </message>
</context>
</TS>
