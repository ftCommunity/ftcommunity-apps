#!/bin/sh
python3 /media/sdcard/apps/6026c098-cb9b-45da-9c8c-9d05eb44a4fd/telegram-service.py &
